# crud_django
Django REST with CRUD table
