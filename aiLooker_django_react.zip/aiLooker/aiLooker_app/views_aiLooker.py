from rest_framework.decorators import api_view
from django.shortcuts import HttpResponse
from rest_framework import status
from django.forms.models import model_to_dict
from django.core.exceptions import ObjectDoesNotExist
from aiLooker_app.models import Tbladvtbsc
import json
import datetime


def serialize_aiLooker(aiLooker):
    serialized = model_to_dict(aiLooker)
    serialized["AdvtNo"]        = int(aiLooker.AdvtNo)              # 광고번호
    serialized["AdvtTpCd"]      = str(aiLooker.AdvtTpCd)            # 광고종류코드
    serialized["AdvtTitl"]      = str(aiLooker.AdvtTitl)            # 광고제목
    serialized["AdvtStaDate"]   = str(aiLooker.AdvtStaDate)         # 광고시작일자
    serialized["AdvtEndDate"]   = str(aiLooker.AdvtEndDate)         # 광고종료일자
    serialized["AdvtDesc"]      = str(aiLooker.AdvtDesc)            # 광고내요
    serialized["AdvtDescPath"]  = str(aiLooker.AdvtDescPath)        # 광고내용경로
    serialized["AdvtGrdCd"]     = str(aiLooker.AdvtGrdCd)           # 광고등급코드
    serialized["DelYN"]         = str(aiLooker.DelYN)               # 삭제여부
    serialized["FstAddTmst"]    = str(aiLooker.FstAddTmst)          # 최초등록일시
    serialized["FstAddID "]     = str(aiLooker.FstAddID)            # 최초등록ID
    serialized["LastUptTmst"]   = str(aiLooker.LastUptTmst)         # 최종변경일시
    serialized["LastUptID"]     = str(aiLooker.LastUptID)           # 최종변경ID

    return serialized

def save_aiLooker(request, aiLooker, success_status):
    errors = []
    AdvtNo = request.data.get("AdvtNo", "")
    if AdvtNo == "":
        errors.append({"AdvtNo": "This field is required"})

    AdvtTpCd = request.data.get("AdvtTpCd", "")
    if AdvtTpCd == "":
        errors.append({"AdvtTpCd": "This field is required"})

    AdvtTitl = request.data.get("AdvtTitl", "")
    if AdvtTitl == "":
        errors.append({"AdvtTitl": "This field is required"})

    AdvtStaDate = request.data.get("AdvtStaDate", "")
    if AdvtStaDate == "":
        AdvtStaDate = datetime.datetime.now()

    AdvtEndDate = request.data.get("AdvtEndDate", "")
    if AdvtEndDate == "":
        AdvtEndDate = datetime.datetime.now()

    AdvtDesc = request.data.get("AdvtDesc", "")
    if AdvtDesc == "":
        errors.append({"AdvtDesc": "This field is required"})

    AdvtDescPath = request.data.get("AdvtDescPath", "")
    if AdvtDescPath == "":
        errors.append({"AdvtDescPath": "This field is required"})

    AdvtGrdCd = request.data.get("AdvtGrdCd", "")
    if AdvtGrdCd == "":
        errors.append({"AdvtGrdCd": "This field is required"})

    DelYN = request.data.get("DelYN", "")
    if DelYN == "":
        DelYN = "N"

    FstAddTmst = request.data.get("FstAddTmst", "")
    if FstAddTmst == "":
        FstAddTmst = datetime.datetime.now()

    FstAddID = request.data.get("FstAddID", "")
    if FstAddID == "":
        FstAddID = "admin"

    LastUptTmst = request.data.get("LastUptTmst", "")
    if LastUptTmst == "":
        LastUptTmst = datetime.datetime.now()

    LastUptID = request.data.get("LastUptID", "")
    if LastUptID == "":
        LastUptID = "admin"        

    if len(errors) > 0:
        return HttpResponse(json.dumps(
            {
                "errors": errors
            }), status=status.HTTP_400_BAD_REQUEST)

    try:
        aiLooker.AdvtNo       = AdvtNo                               # 광고번호
        aiLooker.AdvtTpCd     = AdvtTpCd                             # 광고종류코드
        aiLooker.AdvtTitl     = AdvtTitl                             # 광고제목
        aiLooker.AdvtStaDate  = AdvtStaDate                          # 광고시작일자
        aiLooker.AdvtEndDate  = AdvtEndDate                          # 광고종료일자
        aiLooker.AdvtDesc     = AdvtDesc                             # 광고내용
        aiLooker.AdvtDescPath = AdvtDescPath                         # 광고내용경로
        aiLooker.AdvtGrdCd    = AdvtGrdCd                            # 광고등급코드
        aiLooker.DelYN        = DelYN                                # 삭제여부
        aiLooker.FstAddTmst   = FstAddTmst                           # 최초등록일시
        aiLooker.FstAddID     = FstAddID                             # 최초등록ID
        aiLooker.LastUptTmst  = LastUptTmst                          # 최종변경일시
        aiLooker.LastUptID    = LastUptID                            # 최종변경ID                                               

        aiLooker.save()

    except Exception as e:
        return HttpResponse(json.dumps(
            {
                "errors": {"Tbladvtbsc": str(e)}
            }), status=status.HTTP_400_BAD_REQUEST)

    return HttpResponse(json.dumps({"data": serialize_aiLooker(aiLooker)}), status=success_status)


@api_view(['GET', 'POST'])
def aiLookers(request):
    if request.user.is_anonymous:
        return HttpResponse(json.dumps({"detail": "Not authorized"}), status=status.HTTP_401_UNAUTHORIZED)

    if request.method == "GET":
        aiLookers_data = Tbladvtbsc.objects.all()
        aiLookers_count= aiLookers_data.count()

        page_size      = int(request.GET.get("page_size", "5"))
        page_no        = int(request.GET.get("page_no"  , "0"))
        aiLookers_data = list(aiLookers_data[page_no * page_size:page_no * page_size + page_size])

        aiLookers_data = [serialize_aiLooker(aiLooker) for aiLooker in aiLookers_data]
        return HttpResponse(json.dumps({"count": aiLookers_count, "data": aiLookers_data}), status=status.HTTP_200_OK)

    if request.method == "POST":
        aiLooker = Tbladvtbsc()
        return save_aiLooker(request, aiLooker, status.HTTP_201_CREATED)

    return HttpResponse(json.dumps({"detail": "Wrong method"}), status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'PUT', 'DELETE'])
def aiLooker(request, AdvtNo):
    if request.user.is_anonymous:
        return HttpResponse(json.dumps({"detail": "Not authorized"}), status=status.HTTP_401_UNAUTHORIZED)

    try:
        aiLooker = Tbladvtbsc.objects.get(pk=AdvtNo)
    except ObjectDoesNotExist:
        return HttpResponse(json.dumps({"detail": "Not found"}), status=status.HTTP_404_NOT_FOUND)

    if request.method == "GET":
        return HttpResponse(json.dumps({"data": serialize_aiLooker(aiLooker)}), status=status.HTTP_200_OK)

    if request.method == "PUT":
        return save_aiLooker(request, aiLooker, status.HTTP_200_OK)

    if request.method == "DELETE":
        aiLooker.delete()
        return HttpResponse(json.dumps({"detail": "deleted"}), status=status.HTTP_410_GONE)

    return HttpResponse(json.dumps({"detail": "Wrong method"}), status=status.HTTP_501_NOT_IMPLEMENTED)
