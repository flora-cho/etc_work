from django.contrib import admin
from aiLooker_app.models import Tbladvtbsc

admin.site.register(Tbladvtbsc)
