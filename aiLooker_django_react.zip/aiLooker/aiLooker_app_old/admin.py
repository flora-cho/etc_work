from django.contrib import admin
from aiLooker_app.models import Tbladvtbsc
from aiLooker_app.models import Tblphnnolist

admin.site.register(Tbladvtbsc)
admin.site.register(Tblphnnolist)
