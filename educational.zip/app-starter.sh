# use this shellscript code if you forgot the command how to operate Flask
#!/bin/sh
FLASK_APP=app.py FLASK_DEBUG=1 flask run
