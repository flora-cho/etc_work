import hashlib
import bcrypt

m = hashlib.sha256()
m.update(b"test password")
hex_p = m.hexdigest()
print("sha256 only: ", hex_p)

bc = bcrypt.hashpw(b"test password", bcrypt.gensalt()).hex()
print("with bcrypt: ", bc)

import jwt
data_to_encode = {'some': 'payload'}
encryption_secrete = 'secrete'
algorithm = 'HS256'
encoded = jwt.encode(data_to_encode, encryption_secrete, algorithm=algorithm)
print("JWT encoded: ", encoded)

decode = jwt.decode(encoded, 'secrete', algorithms=[algorithm])
print("JWT decoded: ", decode)